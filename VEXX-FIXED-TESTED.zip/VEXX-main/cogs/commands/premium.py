import sqlite3
from pathlib import Path

import discord
from discord.ext import commands

from utils.config import OWNER_IDS


class Premium(commands.Cog):
    """Owner-only premium user management for VEXX."""
    def __init__(self, bot):
        self.bot = bot
        Path("db").mkdir(exist_ok=True)
        self.db_path = "db/premium.db"
        with sqlite3.connect(self.db_path) as db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS premium_users (
                    user_id INTEGER PRIMARY KEY,
                    plan TEXT NOT NULL DEFAULT 'Premium',
                    added_by INTEGER NOT NULL,
                    added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
            """)
            db.execute("""
                CREATE TABLE IF NOT EXISTS premium_config (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
            """)

    async def cog_check(self, ctx):
        try:
            return ctx.author.id in OWNER_IDS or await self.bot.is_owner(ctx.author)
        except Exception:
            return ctx.author.id in OWNER_IDS

    @commands.group(name="premium", invoke_without_command=True)
    async def premium(self, ctx):
        await ctx.reply(
            "**Premium Management**\n"
            "`>premium add @user [plan]`\n"
            "`>premium remove @user`\n"
            "`>premium status [@user]`\n"
            "`>premium list`\n"
            "`>premium config name <name>`\n"
            "`>premium config color <#hex>`",
            mention_author=False
        )

    @premium.command(name="add")
    async def premium_add(self, ctx, user: discord.User, *, plan="Premium"):
        with sqlite3.connect(self.db_path) as db:
            db.execute(
                "INSERT INTO premium_users(user_id, plan, added_by) VALUES(?,?,?) "
                "ON CONFLICT(user_id) DO UPDATE SET plan=excluded.plan, added_by=excluded.added_by",
                (user.id, plan[:60], ctx.author.id)
            )
        await ctx.reply(
            f"✅ Premium enabled for {user.mention} — **{discord.utils.escape_markdown(plan[:60])}**.",
            mention_author=False
        )

    @premium.command(name="remove")
    async def premium_remove(self, ctx, user: discord.User):
        with sqlite3.connect(self.db_path) as db:
            cur = db.execute("DELETE FROM premium_users WHERE user_id=?", (user.id,))
        message = (
            f"✅ Removed premium for {user.mention}."
            if cur.rowcount else f"ℹ️ {user.mention} was not on the premium list."
        )
        await ctx.reply(message, mention_author=False)

    @premium.command(name="status")
    async def premium_status(self, ctx, user: discord.User = None):
        user = user or ctx.author
        with sqlite3.connect(self.db_path) as db:
            row = db.execute(
                "SELECT plan, added_at FROM premium_users WHERE user_id=?", (user.id,)
            ).fetchone()
        if row:
            await ctx.reply(
                f"✅ **Premium Active**\nUser: {user.mention}\n"
                f"Plan: **{discord.utils.escape_markdown(row[0])}**\nAdded: `{row[1]} UTC`",
                mention_author=False
            )
        else:
            await ctx.reply(f"ℹ️ {user.mention} does not have premium.", mention_author=False)

    @premium.command(name="list")
    async def premium_list(self, ctx):
        with sqlite3.connect(self.db_path) as db:
            rows = db.execute(
                "SELECT user_id, plan, added_at FROM premium_users ORDER BY added_at DESC LIMIT 50"
            ).fetchall()
        if not rows:
            return await ctx.reply("No premium users yet.", mention_author=False)
        lines = [
            f"`#{i}` <@{uid}> — **{discord.utils.escape_markdown(plan)}** · `{added}`"
            for i, (uid, plan, added) in enumerate(rows, 1)
        ]
        embed = discord.Embed(
            title=f"Premium Users ({len(rows)})",
            description="\n".join(lines),
            color=0x00D4FF
        )
        await ctx.reply(embed=embed, mention_author=False)

    @premium.group(name="config", invoke_without_command=True)
    async def premium_config(self, ctx):
        await ctx.reply(
            "Use `>premium config name <name>` or `>premium config color <#hex>`.",
            mention_author=False
        )

    async def _set_config(self, ctx, key, value):
        with sqlite3.connect(self.db_path) as db:
            db.execute(
                "INSERT INTO premium_config(key,value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, value)
            )
        await ctx.reply(f"✅ Premium {key} set to `{value}`.", mention_author=False)

    @premium_config.command(name="name")
    async def premium_config_name(self, ctx, *, name):
        await self._set_config(ctx, "name", name[:80])

    @premium_config.command(name="color")
    async def premium_config_color(self, ctx, color):
        value = color.lstrip("#")
        if len(value) != 6 or any(c not in "0123456789abcdefABCDEF" for c in value):
            return await ctx.reply(
                "Use a valid hex color, e.g. `>premium config color #00D4FF`.",
                mention_author=False
            )
        await self._set_config(ctx, "color", "#" + value.upper())


async def setup(bot):
    await bot.add_cog(Premium(bot))
