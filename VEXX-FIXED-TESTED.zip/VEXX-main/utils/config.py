import os

TOKEN = os.environ.get("TOKEN")
NAME = "Axon X"
server = "https://discord.com/invite/codexdev"
ch = "https://discord.com/channels/699587669059174461/1271825678710476911"
_DEFAULT_OWNER_IDS = [767979794411028491, 912362112620331029, 1297508239029698695, 1010057368287068222]
_ENV_OWNER_IDS = [
    int(value.strip())
    for value in os.getenv("BOT_OWNER_IDS", "").split(",")
    if value.strip().isdigit()
]
OWNER_IDS = list(dict.fromkeys(_DEFAULT_OWNER_IDS + _ENV_OWNER_IDS))
BotName = "Axon X"
serverLink = "https://discord.com/invite/codexdev"