import os

def _read_owner_ids():
    """Read bot owner IDs from Railway/Codespaces environment variables."""
    raw = os.getenv("BOT_OWNER_IDS", os.getenv("VEXX_OWNER_IDS", ""))
    ids = []
    for value in raw.split(","):
        value = value.strip()
        if value.isdigit() and int(value) not in ids:
            ids.append(int(value))
    return ids

TOKEN = os.getenv("TOKEN")
NAME = "VEXX"
server = os.getenv("SUPPORT_SERVER_URL", "https://discord.com")
ch = os.getenv("LOG_CHANNEL_URL", "")
OWNER_IDS = _read_owner_ids()
BotName = "VEXX"
serverLink = server
